package com.example.formularioestudante

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.studentapp.StudentAdapter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val students = mutableListOf<String>()
    private lateinit var adapter: StudentAdapter
    private lateinit var editTextName: EditText
    private lateinit var editTextArea: EditText
    private lateinit var listViewStudents: ListView
    private lateinit var textViewCount: TextView
    private lateinit var textViewDate: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.editTextName)
        editTextArea = findViewById(R.id.editTextArea)
        listViewStudents = findViewById(R.id.listViewStudents)
        textViewCount = findViewById(R.id.textViewCount)
        textViewDate = findViewById(R.id.textViewDate)

        adapter = StudentAdapter(this, students)
        listViewStudents.adapter = adapter

        updateDate()

        findViewById<Button>(R.id.buttonAdd).setOnClickListener {
            addStudent()
        }

        findViewById<Button>(R.id.buttonReset).setOnClickListener {
            resetData()
        }
    }

    private fun addStudent() {
        val name = editTextName.text.toString()
        val area = editTextArea.text.toString()
        if (name.isNotBlank() && area.isNotBlank()) {
            students.add("$name - $area")
            adapter.notifyDataSetChanged()
            updateCount()
            editTextName.text.clear()
            editTextArea.text.clear()
        }
    }

    private fun resetData() {
        students.clear()
        adapter.notifyDataSetChanged()
        updateCount()
    }

    private fun updateCount() {
        textViewCount.text = "Quantidade de Alunos: ${students.size}"
    }

    private fun updateDate() {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val currentDate = dateFormat.format(Date())
        textViewDate.text = "Data Atual: $currentDate"
    }
}
